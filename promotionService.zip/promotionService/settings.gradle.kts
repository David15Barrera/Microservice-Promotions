rootProject.name = "promotionService"
